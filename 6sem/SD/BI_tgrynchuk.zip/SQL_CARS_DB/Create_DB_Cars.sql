CREATE DATABASE Cars

use Cars;
create table Countries
(
CountryID int,
Country nvarchar(50),
constraint PK_Countries primary key(CountryID)
)

use Cars;
create table SalesMen
(
SalesmanID int,
Surname nvarchar(50),
Name nvarchar(50),
EmpDate datetime,
BossID int,
constraint PK_SalesMen primary key(SalesmanID)
)

use Cars;
create table Categories
(
CatID int,
Category nvarchar(50),
constraint PK_Categories primary key(CatID)
)

use Cars;
create table Cities
(
CityID int,
City nvarchar(50),
CountryID int not null,
constraint PK_Cities primary key(CityID),

constraint FK_City_Country foreign key(CountryID) 
references Countries(CountryID),
)


use Cars;
create table Company
(
CompanyID int,
Company nvarchar(50),
CityID int not null,
constraint PK_Company primary key(CompanyID),

constraint FK_Company_City foreign key(CityID) 
references Cities(CityID),
)


use Cars;
create table Cars
(
CarID int,
CategoryID int not null,
CompanyID int not null,
Car nvarchar(50),
Model nvarchar(50),

constraint PK_Cars primary key(CarID),

constraint FK_Cars_Category foreign key(CategoryID) 
references Categories(CatID),

constraint FK_Cars_Company foreign key(CompanyID) 
references Company(CompanyID),
)

use Cars;
create table Customers
(
CusID int,
Surname nvarchar(50),
Name nvarchar(50),
CityID int not null,
constraint PK_Customers primary key(CusID),

constraint FK_Customers_City foreign key(CityID) 
references Cities(CityID),
)

use Cars;
create table Transactions_facts_table
(
CarID int,
CustomerID int,
SalesmanID int,
SalesDate datetime,
Price numeric(18,3),
Amount numeric(18,3),
Value numeric(18,3),

constraint FK_Trans_Cars foreign key(CarID) 
references Cars(CarID),

constraint FK_Trans_Customer foreign key(CustomerID) 
references Customers(CusID),

constraint FK_Trans_Salesman foreign key(SalesmanID) 
references SalesMen(SalesmanID),
)

