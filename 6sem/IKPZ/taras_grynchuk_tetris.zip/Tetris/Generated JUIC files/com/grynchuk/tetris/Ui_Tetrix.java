/********************************************************************************
** Form generated from reading ui file 'Tetrix.jui'
**
** Created: �� 11. ��� 13:37:29 2015
**      by: Qt User Interface Compiler version 4.5.2
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

package com.grynchuk.tetris;

import com.trolltech.qt.core.*;
import com.trolltech.qt.gui.*;

import com.trolltech.examples.*;

public class Ui_Tetrix implements com.trolltech.qt.QUiForm<QWidget>
{
    public Tetrix tetrix;

    public Ui_Tetrix() { super(); }

    public void setupUi(QWidget Tetrix)
    {
        Tetrix.setObjectName("Tetrix");
        Tetrix.resize(new QSize(400, 376).expandedTo(Tetrix.minimumSizeHint()));
        tetrix = new Tetrix(Tetrix);
        tetrix.setObjectName("tetrix");
        tetrix.setGeometry(new QRect(30, 10, 336, 350));
        retranslateUi(Tetrix);

        Tetrix.connectSlotsByName();
    } // setupUi

    void retranslateUi(QWidget Tetrix)
    {
        Tetrix.setWindowTitle(com.trolltech.qt.core.QCoreApplication.translate("Tetrix", "Form", null));
    } // retranslateUi

}

