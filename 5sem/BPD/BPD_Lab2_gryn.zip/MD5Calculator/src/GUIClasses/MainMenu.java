

package GUIClasses;

import javax.swing.*;
import java.awt.event.*;
import java.util.ResourceBundle;
import java.util.Locale;
import GUIInterfaces.ChangeLanguageListener;


public class MainMenu extends JMenuBar implements ActionListener,
    ChangeLanguageListener {
    
    private JMenu languageMenu;
    private JMenu helpMenu;
    private JMenuItem menuItem;
    private JRadioButtonMenuItem rbMenuItem;
    private ResourceBundle messages;
    private java.util.List clListeners;
    

    public MainMenu(ResourceBundle messages) {

        this.messages = messages;

        clListeners = new java.util.ArrayList();
    }

    public void actionPerformed(ActionEvent actionEvent) {
    }
    public void changeLanguage(ResourceBundle mes) {
        this.messages = mes;
     }
      public void addChangeLanguageListener(ChangeLanguageListener listener) {
        clListeners.add(listener);
    }
}
