/*
 * Created on 27.07.2005
 *
 */
package classes;

import interfaces.MD5CalculationProgressListener;
import interfaces.MD5CalculatorStateListener;
import java.util.*;
import java.io.*;

/**

* Цей клас виконує аналіз дерева папок, і розрахунок MD5 сум файлів,
  * Містяться в них.
  * Для аналізу папки використовується метод analyse.
  * Якщо є класи, яким необхідна інформація про хід рассчета, то вони
  * Можуть зареєструватися за допомогою методів addMD5CalculatorStateListener і
  * AddMD5CalculationProgressListener.
  * Метод stop зупиняє процес розрахунку.
 */
public class FolderTreeAnalyser {

    private List fileList = null; 
    private List results = null; 
    private List listeners = null; 
    							   
    private MD5Calculator calculator = null; 
    										 
    private boolean stop = false; 
    private int filesCount = 0; 
    private int folderCount = 0; 
    private long filesSize = 0; 
    
    /**
     * Конструктор.
     */
    public FolderTreeAnalyser() {
        
        fileList = new ArrayList();
        results = new ArrayList();
        listeners = new ArrayList();
        calculator = new MD5Calculator();
        stop = false;
    }
    
    /**
       * Реєструє клас, який буде отримувати повідомлення про аналізі поточної
      * Папки.
      *param Listener покажчик на клас, якому потрібна інформація про процес
      * Аналізу (він повинен реалізовувати інтерфейс MD5CalculatorStateListener).
     */
    public void addMD5CalculatorStateListener(MD5CalculatorStateListener listener) {
        if(listener != null && listeners != null) {
            listeners.add(listener);
        }
    }
    
    /**
      * Реєструє клас, який буде отримувати повідомлення про розрахунок MD5 суми
      * Конкретного файлу.
      *param Listener покажчик на клас, якому потрібна інформація про процес
      * Розрахунку (він повинен реалізовувати інтерфейс MD5CalculationProgressListener).
      */
    public void addMD5CalculationProgressListener(
            MD5CalculationProgressListener listener) {
        if(listener != null && calculator != null) {
            calculator.setMD5CalculationProgressListener(listener);
        }
    }
    
    /**
      * Виконує розрахунок MD5 сум для всіх файлів в заданій папці.
      *param FolderName ім'я папки
      *return List, що містить рядки з іменами файлів і їх MD5 сумами, якщо
      * Розрахунок завершений успішно, null - в іншому випадку
      *throws IOException якщо виникли помилки введення-виведення
      */
    public List analyse(String folderName) throws IOException {
        stop = false;
        fileList.clear();
        results.clear();
        filesCount = 0;
        folderCount = 0;
        filesSize = 0;
        File startingFolder = new File(folderName);
        if(startingFolder.exists() == false) {
            throw new IOException();
        }
        for(int i = 0; i < listeners.size(); i++) {
            ((MD5CalculatorStateListener)(listeners.get(i))).folderStructureAnalyseBegin();
        }
        if(startingFolder.isFile()) {
            for(int i = 0; i < listeners.size(); i++) {
                ((MD5CalculatorStateListener)(listeners.get(i))).folderStructureAnalyseEnd(
                        0, 1, startingFolder.length());
            }
            for(int i = 0; i < listeners.size(); i++) {
                ((MD5CalculatorStateListener)(listeners.get(i))).MD5SumCalculationBegin(
                        startingFolder.getName(), startingFolder.length());
            }
            //розрахуємо MD5 суму
            calculator.readMessage(startingFolder);
            String md5sum = calculator.calculate();
            
            //формуем результат, і добавляемо його в список
            String res = new String(md5sum + " *" + startingFolder.getName());
            results.add(res);
            for(int i = 0; i < listeners.size(); i++) {
                ((MD5CalculatorStateListener)(listeners.get(i))).MD5SumCalculationEnd(
                        startingFolder.getName());
            }
        }
        else {
            for(int i = 0; i < listeners.size(); i++) {
                ((MD5CalculatorStateListener)(listeners.get(i))).folderStructureAnalyseBegin();
            }
            //початок аналізу папки
            analyseFolderTree(startingFolder);

            for(int i = 0; i < listeners.size(); i++) {
                ((MD5CalculatorStateListener)(listeners.get(i))).folderStructureAnalyseEnd(
                        folderCount, filesCount, filesSize);
            }
            if(fileList == null) {
                return null;
            }
            if(fileList.size() == 0) {
                for(int k = 0; k < listeners.size(); k++) {
                    ((MD5CalculatorStateListener)(
                            listeners.get(k))).MD5SumCalculationEnd("");
                }
                return results;
            }
            for(int i = 0; i < fileList.size(); i++) {
                if(stop == true) {
                    return null;
                }
                for(int j = 0; j < listeners.size(); j++) {
                    ((MD5CalculatorStateListener)(listeners.get(j))).MD5SumCalculationBegin(
                            ((File)(fileList.get(i))).getName(), ((File)(fileList.get(i))).length());
                }
                File curFile = (File)fileList.get(i);
                calculator.readMessage(curFile);
                String md5sum = calculator.calculate();
                String relPath = getRelativePath(startingFolder.getAbsolutePath(),
                        curFile.getAbsolutePath());
                String res = new String(md5sum + " *" + relPath);
                results.add(res);
                for(int k = 0; k < listeners.size(); k++) {
                    ((MD5CalculatorStateListener)(listeners.get(k))).MD5SumCalculationEnd(
                            ((File)(fileList.get(i))).getName());
                }
            }
        }
        return results;
    }
    
    /**
      * Зупиняє процес розрахунку. Має сенс використовувати якщо
      * Метод analyse () запущений в окремому потоці.
      *
    */    
    public void stopAnalyse() {
        calculator.stopCalculation();
        stop = true;
    }
    

    public int getFilesCount() {
        return filesCount;
    }

    public int getFolderCount() {
        return folderCount;
    }
    

    public long getFilesSize() {
        return filesSize;
    }
    
    /**
      * Цей метод повертає шлях до файлу, щодо заданої папки.
      *param BasePath шлях до заданої папці
      *param FullPath повний шлях до файлу
      *return Шлях до файлу щодо заданої папки
      */  
    public static String getRelativePath(String basePath, String fullPath) {
        StringBuffer res = new StringBuffer(fullPath);
        res.delete(0, basePath.length() + 1);
        return res.toString();
    }
    
    /*
      * Виконує складання списку файлів в заданій папці та її підпапках,
      * Складає їх список, розраховує їх загальний розмір і вважає
      * Кількість вкладених папок.
      */
    
    private void analyseFolderTree(File folderName) {
        if(stop == true) {
            return;
        }
        if(folderName.isFile()) {
            return;
        }
        folderCount++;
        File[] files = folderName.listFiles();
        if(files == null) {
            return;
        }
        if(files.length == 0) {
            return;
        }
        for(int i = 0; i < files.length; i++) {
            //якщо папка - рекурсивно
            if(files[i].isDirectory()) {
                analyseFolderTree(files[i]);
            }
            //якщо файл
            else {
                
                filesCount++;
                filesSize += files[i].length();
                fileList.add(files[i]);
            }
        }
    }
}
