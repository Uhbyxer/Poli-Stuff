package GUIInterfaces;

import java.util.ResourceBundle;


public interface ChangeLanguageListener {
    public void changeLanguage(ResourceBundle mes);
}

