
package interfaces;


public interface MD5CalculatorStateListener {

    public void folderStructureAnalyseBegin();
    

    public void folderStructureAnalyseEnd(int folderCount,
            int filesCount, long filesSize);

    public void MD5SumCalculationBegin(String fileName, long fileLength);

    public void MD5SumCalculationEnd(String fileName);
}
