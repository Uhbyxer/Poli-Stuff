
package interfaces;

public interface MD5CalculationProgressListener {

    public void setNewMD5ProgressValue(float f);
}