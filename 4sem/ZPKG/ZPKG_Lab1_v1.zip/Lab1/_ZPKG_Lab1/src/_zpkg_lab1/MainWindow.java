/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package _zpkg_lab1;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;

/**
 *
 * @author Taras
 */
public class MainWindow {
    static final int x0 = 200, y0 = 100;
    
    //координати першої точки
    private final int firstX, firstY; 
    //тип руху: поворот/маштабування
    private final MoveKind move;
    //кут повороту (в градусах)
    private final int angle;
    //коефыцыэнт шаттабування
    private final double scale;
    
    //конструктор
    public MainWindow(int firstX, int firstY,  MoveKind move, int angle, double scale) {
        this.firstX = firstX;
        this.firstY = firstY;
        this.move = move;
        this.angle = angle;
        this.scale = scale;
    }  
    
    public void show() {
        //створюэмо форму
        JFrame fr=new JFrame("Афінні перетворення");
        //розмыр вікна
        fr.setPreferredSize( new Dimension(650,550));
        fr.setResizable(false);
        final JPanel pan= new JPanel();
        fr.add(pan);
        fr.setVisible(true);
        //fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fr.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        fr.pack();
        
        //таймер. кожних 500 мілісекунд пересальовуємо форму
        Timer tm;
        tm = new Timer(500, new ActionListener(){
            int i = 0;
            @Override
            public void actionPerformed(ActionEvent arg0) {
                Graphics2D gr=(Graphics2D)pan.getRootPane().getGraphics();
                pan.update(gr);
                GeneralPath path=new GeneralPath();
                
                //малюємо трикутник відносно координат першої точки
                path.append(new Polygon(
                        //масив координат Х
                        new int []{ x0 + firstX, //перша точка
                            x0 + firstX - 170, //друга
                            x0 + firstX - 10}, //третя
                        //масив координат У
                        new int[]{y0 + firstY, //перша точка 
                            y0 + firstY + 10, //друга
                            y0 + firstY + 100} //третя
                        , 3), true);
                

                //переводимо наше систему коорднат в координати пікселів на формі
                gr.translate(150, 150);
                
                //gr.draw(path);
                
                //клас афінних перетворень
                AffineTransform tranforms = null;
                
                
                if(move == MoveKind.ROTATE) { 
                    //координати точки, відносно якої робимо поворот
                    int x = (x0 + firstX), y = (y0 + firstY);
                    
                    //0.07 - крок одного повороту (в радіанах)
                    if(i*0.07 <= angle * Math.PI/180) {  //переводимо angle в радіани
                        //поворот
                        tranforms = AffineTransform.getRotateInstance((i++)*0.07, x, y);
                        
                        //перемалюємо, згідно нових координат
                        gr.transform(tranforms);
                        gr.draw(path);
                        
                    }
                    
                } else if (move == MoveKind.SCALE) {
                    //маштабування (0.07 - крок маштабування)
                    if(1 + i*0.07 <= scale) {
                        //маштабування
                        tranforms = AffineTransform.getScaleInstance(1 + i*0.07, 1 + (i++)*0.07);
                        
                        //перемалюємо, згідно нових координат
                        gr.transform(tranforms);
                        gr.draw(path);
                    }
                } else
                    throw new RuntimeException("Не вказано тип перетворень !");
                
            }});
        tm.start();
    }
}
