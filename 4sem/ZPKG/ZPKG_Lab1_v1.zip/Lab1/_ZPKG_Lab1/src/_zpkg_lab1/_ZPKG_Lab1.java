/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package _zpkg_lab1;

/**
 *
 * @author Taras
 */
public class _ZPKG_Lab1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        StartWindow.main(null);
        //MainWindow.main(null);
        //new MainWindow(0, 0, MoveKind.ROTATE, 180, 3.0).show();
    }
    
}
