﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MediaSamples
{
    /// <summary>
    /// Interaction logic for MediaPlayerSample.xaml
    /// </summary>
    public partial class MediaPlayerSample : Page
    {
        public MediaPlayerSample()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            ////
            //// Create a VideoDrawing that repeats.
            ////

            //// Create a MediaTimeline.
            //MediaTimeline mTimeline =
            //    new MediaTimeline(new Uri(@"sampleMedia\xbox.wmv", UriKind.Relative));

            //// Set the timeline to repeat.
            //mTimeline.RepeatBehavior = RepeatBehavior.Forever;

            //// Create a clock from the MediaTimeline.
            //MediaClock mClock = mTimeline.CreateClock();

            //MediaPlayer repeatingVideoDrawingPlayer = new MediaPlayer();
            //repeatingVideoDrawingPlayer.Clock = mClock;

            //VideoDrawing repeatingVideoDrawing = new VideoDrawing();
            //repeatingVideoDrawing.Rect = new Rect(150, 0, 100, 100);
            //repeatingVideoDrawing.Player = repeatingVideoDrawingPlayer;

            //
            // Create a VideoDrawing.
            //      
            MediaPlayer player = new MediaPlayer();
            player.Open(new Uri(@"C:\Projects\WPF\MediaSamples\MediaSamples\Media\Lake.wmv", UriKind.Relative));
            VideoDrawing aVideoDrawing = new VideoDrawing();
            aVideoDrawing.Rect = new Rect(0, 0, 100, 100);
            aVideoDrawing.Player = player;
            // Play the video once.
            player.Play();      
        }
    }
}
