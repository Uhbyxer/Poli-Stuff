﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;


namespace MediaSamples
{
    /// <summary>
    /// Interaction logic for Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        public Page1()
        {
            InitializeComponent();
        }

      

        private void Element_MediaEnded(object sender, RoutedEventArgs e)
        {

        }
        
        // Включити відео
        void OnMouseDownPlayMedia(object sender, MouseButtonEventArgs args)
        {

            McMediaElement.Play();

            // Ініціалізація властивостей медіа
            InitializePropertyValues();

        }

        // Пауза
        void OnMouseDownPauseMedia(object sender, MouseButtonEventArgs args)
        {

            McMediaElement.Pause();

        }

        // Стоп
        void OnMouseDownStopMedia(object sender, MouseButtonEventArgs args)
        {

            McMediaElement.Stop();

        }

        // Рівень гучності
        private void ChangeMediaVolume(object sender, RoutedPropertyChangedEventArgs<double> args)
        {
            McMediaElement.Volume = (double)volumeSlider.Value;
        }

        // Зміна швидкості
        private void ChangeMediaSpeedRatio(object sender, RoutedPropertyChangedEventArgs<double> args)
        {
            McMediaElement.SpeedRatio = (double)speedRatioSlider.Value;
        }

        // Ініціалізація макс. точки повзунка кількістю мілісекунд кліпу
        private void Element_MediaOpened(object sender, EventArgs e)
        {
            timelineSlider.Maximum = McMediaElement.NaturalDuration.TimeSpan.TotalMilliseconds;
        }

        // Стоп медіа, коли воно завершиться
        private void Element_MediaEnded(object sender, EventArgs e)
        {
            McMediaElement.Stop();
        }

        // Перехід по відео
        private void SeekToMediaPosition(object sender, RoutedPropertyChangedEventArgs<double> args)
        {
            int SliderValue = (int)timelineSlider.Value;
            TimeSpan ts = new TimeSpan(0, 0, 0, 0, SliderValue);
            McMediaElement.Position = ts;
        }

        void InitializePropertyValues()
        {
            // Встановлення початкових значень швидкості та рівня звуку
            McMediaElement.Volume = (double)volumeSlider.Value;
            McMediaElement.SpeedRatio = (double)speedRatioSlider.Value;
        }

        // відкриття файлу відео
        private void BrowseButtonClick(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.InitialDirectory = "d:\\fims\\";
            dlg.Filter = "Файли Відео (*.avi)|*.avi|Всі файли (*.*)|*.*";
            dlg.RestoreDirectory = true;

            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)           
            {
                string selectedFileName = dlg.FileName;
                McMediaElement.Source = new Uri(selectedFileName);
                McMediaElement.Play();             
            }
        }
    }
}
