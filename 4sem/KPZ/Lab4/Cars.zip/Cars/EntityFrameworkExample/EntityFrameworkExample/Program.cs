﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessObjects;

namespace EntityFrameworkExample
{
    class Program
    {
        static void Main(string[] args)
        {
            SampleDBEntities db = new SampleDBEntities();
            Cars car = new Cars();
            car.Brand = "Ford";
            car.Model = "195";
            car.CarID = 1;
            db.Cars.Add(car);
            try
            {
                db.SaveChanges();
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.ToString());
                    Console.ReadKey();
                return;
            }

            Console.WriteLine("Ok");
            Console.ReadKey();
        }
    }
}
